// Visitor count shown at the top right of the website.
// GET  /api/visits -> {total, today}
// POST /api/visits -> counts one visit (the page sends it once a day per browser) and returns {total, today}
//                      and notes the visitor's IP address, place and device in the admin's visitor list (kept 90 days)
import { getStore } from "@netlify/blobs";

const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
const BOT = /bot|crawl|spider|slurp|preview|facebookexternalhit|whatsapp|headless|lighthouse/i;

const KEEP_MS = 90 * 86400000, MAX_LOG = 5000;
const clip = (v, n) => String(v == null ? "" : v).replace(/[\u0000-\u001f<>]/g, " ").trim().slice(0, n);
export default async (req, context) => {
  const store = getStore({ name: "site-admin", consistency: "strong" });
  const day = new Date(Date.now() + 5.5 * 3600 * 1000).toISOString().slice(0, 10);   // India date
  const v = (await store.get("visits", { type: "json" })) || { total: 0, day, today: 0 };
  if (v.day !== day) { v.day = day; v.today = 0; }
  if (req.method === "POST" && !BOT.test(req.headers.get("user-agent") || "")) {
    v.total = (v.total || 0) + 1; v.today = (v.today || 0) + 1;
    await store.setJSON("visits", v);
    try {
      const g = (context && context.geo) || {}, now = Date.now();
      const ip = (context && context.ip) || req.headers.get("x-nf-client-connection-ip") || "";
      let body = {}; try { body = await req.json(); } catch (e) {}
      const log = ((await store.get("visit-log", { type: "json" })) || []).filter(x => now - x.t < KEEP_MS);
      log.push({ t: now, ip: clip(ip, 60), city: clip(g.city, 60), state: clip(g.subdivision && g.subdivision.name, 60), country: clip(g.country && (g.country.name || g.country.code), 60),
        ua: clip(req.headers.get("user-agent"), 200), page: clip(body.page, 60), ref: clip(body.ref, 120) });
      while (log.length > MAX_LOG) log.shift();
      await store.setJSON("visit-log", log);
    } catch (e) {}
  } else if (req.method !== "GET" && req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  return json({ total: v.total || 0, today: v.today || 0 });
};

export const config = { path: "/api/visits" };
