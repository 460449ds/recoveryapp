// Visitor count shown at the top right of the website.
// GET  /api/visits -> {total, today}
// POST /api/visits -> counts one visit (the page sends it once a day per browser) and returns {total, today}
//                      and adds one to the visitor's city in the admin's city list (nothing else about the visitor is kept)
import { getStore } from "@netlify/blobs";

const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
const BOT = /bot|crawl|spider|slurp|preview|facebookexternalhit|whatsapp|headless|lighthouse/i;

const clip = (v, n) => String(v == null ? "" : v).replace(/[\u0000-\u001f<>]/g, " ").trim().slice(0, n);
export default async (req, context) => {
  const store = getStore({ name: "site-admin", consistency: "strong" });
  const day = new Date(Date.now() + 5.5 * 3600 * 1000).toISOString().slice(0, 10);   // India date
  const v = (await store.get("visits", { type: "json" })) || { total: 0, day, today: 0 };
  if (v.day !== day) { v.day = day; v.today = 0; }
  if (req.method === "POST" && !BOT.test(req.headers.get("user-agent") || "")) {
    v.total = (v.total || 0) + 1; v.today = (v.today || 0) + 1;
    await store.setJSON("visits", v);
    try {   // only the city is kept for the admin — no IP address, device or page is stored
      const city = clip(context && context.geo && context.geo.city, 60) || "Not known";
      const c = (await store.get("visit-cities", { type: "json" })) || {};
      c[city] = (c[city] || 0) + 1;
      await store.setJSON("visit-cities", c);
      if (await store.get("visit-log")) await store.delete("visit-log");   // remove the older IP list
    } catch (e) {}
  } else if (req.method !== "GET" && req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  return json({ total: v.total || 0, today: v.today || 0 });
};

export const config = { path: "/api/visits" };
