// Site settings saved by the admin page: home page text, search engine text and the new-unit calculator.
// GET  /api/config  -> current settings (public, no password data)
// POST /api/config  -> {action:'login'|'save', password, newPassword?, config?}
import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

const MAX = 600000;                       // largest settings file accepted (characters)
const LOCK_AFTER = 5, LOCK_MS = 15 * 60 * 1000;
const hash = (salt, pw) => crypto.createHash("sha256").update(salt + ":" + pw).digest("hex");
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
const same = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };

export default async (req) => {
  const store = getStore({ name: "site-admin", consistency: "strong" });
  if (req.method === "GET") {
    const c = await store.get("config", { type: "json" });
    return json(c || {});
  }
  if (req.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405);

  let body;
  try { body = await req.json(); } catch (e) { return json({ ok: false, error: "Bad request" }, 400); }
  const now = Date.now();
  const lock = (await store.get("lock", { type: "json" })) || { n: 0, t: 0 };
  if (lock.n >= LOCK_AFTER && now - lock.t < LOCK_MS) return json({ ok: false, error: "Too many wrong attempts. Try again after 15 minutes." }, 429);

  const pw = String(body.password || "");
  const auth = await store.get("auth", { type: "json" });
  let ok, mustChange = false;
  if (auth && auth.salt && auth.hash) ok = same(hash(auth.salt, pw), auth.hash);
  else { ok = same(pw, process.env.ADMIN_INITIAL_PASSWORD || "1234"); mustChange = true; }
  if (!ok) {
    const n = (now - lock.t < LOCK_MS ? lock.n : 0) + 1;
    await store.setJSON("lock", { n, t: now });
    return json({ ok: false, error: "Wrong password." }, 401);
  }
  if (lock.n) await store.setJSON("lock", { n: 0, t: 0 });

  if (body.newPassword !== undefined) {
    const np = String(body.newPassword);
    if (np.length < 8) return json({ ok: false, error: "The new password must have at least 8 characters." }, 400);
    const salt = crypto.randomBytes(16).toString("hex");
    await store.setJSON("auth", { salt, hash: hash(salt, np), changed: new Date().toISOString() });
    return json({ ok: true });
  }
  if (mustChange) return json({ ok: true, mustChange: true });

  if (body.action === "save") {
    const c = body.config;
    if (!c || typeof c !== "object" || Array.isArray(c)) return json({ ok: false, error: "Nothing to save." }, 400);
    const text = JSON.stringify(c);
    if (text.length > MAX) return json({ ok: false, error: "Settings are too large." }, 413);
    const prev = await store.get("config", { type: "json" });
    if (prev) await store.setJSON("config-previous", prev);
    c.saved = new Date().toISOString();
    await store.setJSON("config", c);
    return json({ ok: true, saved: c.saved });
  }
  return json({ ok: true });
};

export const config = { path: "/api/config" };
