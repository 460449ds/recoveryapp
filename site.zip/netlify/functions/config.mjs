// Site settings saved by the admin page: home page text, search engine text and the new-unit calculator.
// GET  /api/config  -> current settings (public, no password data)
// POST /api/config  -> {action:'login'|'save'|'payments'|'payment-mark', password, newPassword?, config?}
//                      {action:'payment', svc, doc, loan, amount, payer, mobile, utr}  (visitor, no password)
import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

const MAX = 600000;                       // largest settings file accepted (characters)
const LOCK_AFTER = 5, LOCK_MS = 15 * 60 * 1000;
const hash = (salt, pw) => crypto.createHash("sha256").update(salt + ":" + pw).digest("hex");
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
const MAX_PAYS = 5000;
const SVCS = ["dpr", "cmax", "stock", "cfm", "scb", "fm"];
const clip = (v, n) => String(v == null ? "" : v).replace(/[\u0000-\u001f<>]/g, " ").trim().slice(0, n);
function feeFor(pricing, svc, loan) {
  const rows = (pricing && Array.isArray(pricing.rows) ? pricing.rows : []).filter(r => r && r.svc === svc && +r.price > 0);
  const hit = rows.find(r => { const f = +r.from || 0, t = (r.to === "" || r.to == null) ? Infinity : +r.to; return loan >= f - 1e-9 && loan <= t + 1e-9; });
  return hit ? Math.round(+hit.price) : 0;
}
async function recordPayment(store, b) {
  const svc = String(b.svc || ""), utr = String(b.utr || "").replace(/\s/g, "").toUpperCase(), mobile = String(b.mobile || "").replace(/\D/g, "");
  const payer = clip(b.payer, 80), doc = clip(b.doc, 120), loan = Math.max(0, Math.round((+b.loan || 0) * 100) / 100);
  if (!SVCS.includes(svc)) return json({ ok: false, error: "Unknown service." }, 400);
  if (!payer) return json({ ok: false, error: "Enter your name." }, 400);
  if (!/^[6-9]\d{9}$/.test(mobile)) return json({ ok: false, error: "Enter a 10-digit mobile number." }, 400);
  if (!/^[A-Z0-9]{10,22}$/.test(utr)) return json({ ok: false, error: "Enter the transaction reference number (UTR) from your payment app." }, 400);
  const cfg = (await store.get("config", { type: "json" })) || {};
  const fee = feeFor(cfg.pricing, svc, loan);
  if (!fee) return json({ ok: true, amount: 0 });
  if (Math.round(+b.amount || 0) !== fee) return json({ ok: false, error: "The fee has changed — please reload the page and try again." }, 409);
  const list = (await store.get("payments", { type: "json" })) || [];
  const dup = list.find(p => p.utr === utr);
  if (dup) {
    if (dup.svc === svc && dup.mobile === mobile && dup.status !== "bad") return json({ ok: true, id: dup.id, amount: dup.amount });
    return json({ ok: false, error: "This transaction reference number has already been used." }, 409);
  }
  const day = Date.now() - 86400000;
  if (list.filter(p => p.mobile === mobile && p.t > day).length >= 20) return json({ ok: false, error: "Too many entries from this mobile number today. Please contact us." }, 429);
  const id = crypto.randomBytes(6).toString("hex");
  list.push({ id, t: Date.now(), svc, doc, loan, amount: fee, payer, mobile, utr, status: "new" });
  while (list.length > MAX_PAYS) list.shift();
  await store.setJSON("payments", list);
  return json({ ok: true, id, amount: fee });
}
const same = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };

export default async (req) => {
  const store = getStore({ name: "site-admin", consistency: "strong" });
  if (req.method === "GET") {
    const c = await store.get("config", { type: "json" });
    return json(c || {});
  }
  if (req.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405);

  let body;
  try { body = await req.json(); } catch (e) { return json({ ok: false, error: "Bad request" }, 400); }
  if (!body || typeof body !== "object") return json({ ok: false, error: "Bad request" }, 400);
  if (body.action === "payment") return recordPayment(store, body);
  const now = Date.now();
  const lock = (await store.get("lock", { type: "json" })) || { n: 0, t: 0 };
  if (lock.n >= LOCK_AFTER && now - lock.t < LOCK_MS) return json({ ok: false, error: "Too many wrong attempts. Try again after 15 minutes." }, 429);

  const pw = String(body.password || "");
  const auth = await store.get("auth", { type: "json" });
  let ok, mustChange = false;
  if (auth && auth.salt && auth.hash) ok = same(hash(auth.salt, pw), auth.hash);
  else { ok = same(pw, process.env.ADMIN_INITIAL_PASSWORD || "1234"); mustChange = true; }
  if (!ok) {
    const n = (now - lock.t < LOCK_MS ? lock.n : 0) + 1;
    await store.setJSON("lock", { n, t: now });
    return json({ ok: false, error: "Wrong password." }, 401);
  }
  if (lock.n) await store.setJSON("lock", { n: 0, t: 0 });

  if (body.newPassword !== undefined) {
    const np = String(body.newPassword);
    if (np.length < 8) return json({ ok: false, error: "The new password must have at least 8 characters." }, 400);
    const salt = crypto.randomBytes(16).toString("hex");
    await store.setJSON("auth", { salt, hash: hash(salt, np), changed: new Date().toISOString() });
    return json({ ok: true });
  }
  if (mustChange) return json({ ok: true, mustChange: true });

  if (body.action === "save") {
    const c = body.config;
    if (!c || typeof c !== "object" || Array.isArray(c)) return json({ ok: false, error: "Nothing to save." }, 400);
    const text = JSON.stringify(c);
    if (text.length > MAX) return json({ ok: false, error: "Settings are too large." }, 413);
    const prev = await store.get("config", { type: "json" });
    if (prev) await store.setJSON("config-previous", prev);
    c.saved = new Date().toISOString();
    await store.setJSON("config", c);
    return json({ ok: true, saved: c.saved });
  }
  if (body.action === "visit-log") {
    return json({ ok: true, visits: (await store.get("visit-log", { type: "json" })) || [] });
  }
  if (body.action === "visit-log-clear") {
    await store.setJSON("visit-log", []);
    return json({ ok: true });
  }
  if (body.action === "payments") {
    return json({ ok: true, payments: (await store.get("payments", { type: "json" })) || [] });
  }
  if (body.action === "payment-mark") {
    const st = String(body.status || "");
    if (!["ok", "bad", "new"].includes(st)) return json({ ok: false, error: "Bad status." }, 400);
    const list = (await store.get("payments", { type: "json" })) || [];
    const p = list.find(x => x.id === body.id);
    if (!p) return json({ ok: false, error: "Payment not found." }, 404);
    p.status = st; p.marked = new Date().toISOString();
    await store.setJSON("payments", list);
    return json({ ok: true });
  }
  return json({ ok: true });
};

export const config = { path: "/api/config" };
