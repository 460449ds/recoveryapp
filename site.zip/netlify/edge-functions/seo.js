// Puts the admin's search engine text and home page text into the page itself,
// so Google and link previews see them without running the page's script.
let cache = { t: 0, c: null };
const esc = (s) => String(s).replace(/[&<>"]/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));

async function getCfg(url) {
  if (Date.now() - cache.t < 60000) return cache.c;
  try {
    const r = await fetch(new URL("/api/config", url), { headers: { accept: "application/json" } });
    cache = { t: Date.now(), c: r.ok ? await r.json() : null };
  } catch (e) { cache = { t: Date.now(), c: cache.c }; }
  return cache.c;
}
function setMeta(html, attr, name, value) {
  const re = new RegExp('(<meta ' + attr + '="' + name + '" content=")[^"]*(")');
  if (re.test(html)) return html.replace(re, (m, a, b) => a + esc(value) + b);
  return html.replace("</head>", '<meta ' + attr + '="' + name + '" content="' + esc(value) + '">\n</head>');
}

export default async (request, context) => {
  const res = await context.next();
  let html = null;
  try {
    if (!(res.headers.get("content-type") || "").includes("text/html")) return res;
    const cfg = await getCfg(request.url);
    if (!cfg || typeof cfg !== "object" || !Object.keys(cfg).length) return res;
    html = await res.text();
    const s = cfg.seo || {};
    if (s.title) html = html.replace(/<title>[\s\S]*?<\/title>/, "<title>" + esc(s.title) + "</title>");
    if (s.description) html = setMeta(html, "name", "description", s.description);
    if (s.keywords) html = setMeta(html, "name", "keywords", s.keywords);
    if (s.ogTitle) html = setMeta(html, "property", "og:title", s.ogTitle);
    if (s.ogDescription) html = setMeta(html, "property", "og:description", s.ogDescription);
    for (const [k, v] of Object.entries(cfg.home || {})) {
      if (!/^[a-z0-9-]+$/.test(k) || typeof v !== "string" || !v.trim()) continue;
      const re = new RegExp('(<([a-z0-9]+)\\b[^>]*\\bdata-ht="' + k + '"[^>]*>)([^<]*)(</\\2>)', "g");
      html = html.replace(re, (m, open, tag, inner, close) => open + esc(v) + close);
    }
    // settings for the page's own script (links / coming soon, site details, texts) — available before it runs
    const safe = JSON.stringify(cfg).replace(/</g, "\\u003c").replace(/\u2028|\u2029/g, "");
    html = html.replace("</head>", "<script>window.__CFG=" + safe + ";</script>\n</head>");
    const headers = new Headers(res.headers);
    headers.delete("content-length");
    headers.set("cache-control", "public, max-age=0, must-revalidate");
    return new Response(html, { status: res.status, headers });
  } catch (e) {
    if (html === null) return res;
    const headers = new Headers(res.headers); headers.delete("content-length");
    return new Response(html, { status: res.status, headers });
  }
};
