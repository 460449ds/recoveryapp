SOLUTION OF ALL FINANCIAL NEED — website for loansinfo.in
Owner shown on the site: Yogesh Shrivastava · avanicorpindia@gmail.com · 9183020110 · Indore

FILES
  index.html      the complete website. Box no. 1 = Loan Recovery Tracking (RecoveryPro),
                  whose Register / Sign in buttons open trackloanrecovery.com.
  PR-14_Pre-Appraisal_Check.html   pre-appraisal check on its own
  _redirects      www.loansinfo.in -> loansinfo.in
  robots.txt, sitemap.xml   for Google (set to loansinfo.in)

WHERE IT LIVES
  Netlify project "loansinfo-in" in Yogesh's account (avanicorpindia@gmail.com), https://loansinfo-in.netlify.app
  trackloanrecovery.com stays the RecoveryPro app, unchanged.

CONNECT loansinfo.in (GoDaddy)
  1. Netlify > project trackloanrecovery-home > Domain management > Add a domain >
     loansinfo.in > Verify > Add domain (also accept www.loansinfo.in).
  2. GoDaddy > My Products > loansinfo.in > DNS > DNS Records:
       A      @     75.2.60.5                         (edit the existing @ "Parked" A record)
       CNAME  www   trackloanrecovery-home.netlify.app (edit the existing www record)
     Delete any other A record for @ (e.g. GoDaddy parking / forwarding).
  3. Wait 10–60 minutes. Netlify then issues the HTTPS certificate on its own
     (Domain management > HTTPS > Verify DNS configuration if it is slow).

NEW UNIT — CAPITAL & VIABILITY CHECK (MSME box, first item)
  The visitor picks an industry and a small project, answers questions about place,
  electricity, category and own money, and only then sees the project cost, own money
  needed, loan, DSCR, break-even and the minimum production/sales to repay the loan.

ADMIN PAGE  https://loansinfo.in/#admin   (footer link "Admin")
  Login password: first login with 1234, then the page asks you to set your own password
  (at least 8 characters). Tabs: Home page text, Search engine text, New unit calculator, Password.
  "Save to website" saves online for every visitor at once — no file upload needed.
  Tabs also include "Links & buttons" (Coming soon / own text on any link, or the whole site)
  and "Site details" (owner, e-mail, phone, city, notice strip).
  Visitor count: shown at the top right of every page (each browser counted once a day; your
  ?preview=avani visits are not counted). Switch it off in Admin > Site details.
  Links & buttons: TICK = the link works for visitors, NO TICK = shows "Coming soon".
  The "Whole website Coming soon" switch overrides all ticks; ticking a link turns it off.
  Saved on Netlify (functions + blobs, project loansinfo-in). 5 wrong passwords lock login for 15 minutes.

PRICING & PAYMENTS (Admin > "Pricing & payments")
  Add one line per service and loan-amount range: service, loan from (Rs lakh), to (Rs lakh,
  blank = and above), fee (Rs); "+ Add price" for more lines. Services with no line are free.
  The "Pricing" menu shows the table to visitors. When a visitor presses PDF / Print or Word on
  a paid output, the fee for that loan amount is asked: UPI QR + UPI ID + bank details, then
  name, mobile and the payment's UTR number. Entries appear under "Payments received":
  check the UTR in your bank / UPI statement and press "Verified" or "Reject"; CSV download.
  Fill "Where payments are received" yourself (UPI ID, account no., IFSC) — use Yogesh's account.
  Note: the UTR is not checked with the bank automatically. For automatic confirmation a
  payment-gateway account (e.g. Razorpay) in Yogesh's name is needed.

COMING SOON MODE (switched on 31 Oct 2026)
  Every link and button on loansinfo.in shows a "Coming soon" note with Yogesh's
  phone and e-mail. Still working: light/dark switch, logo, "Explore modules" scroll,
  phone and e-mail links.
  Full site for the owner only: open https://loansinfo.in/?preview=avani
  (works until that browser tab is closed). To switch the mode off, ask Claude.

UPDATE THE WEBSITE LATER
  Netlify (Yogesh's account) > project loansinfo-in > Deploys > drag this folder onto the page.
